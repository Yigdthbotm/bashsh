<?php

return [
    'bot_token' => env('8180072499:AAF_YXOlI2z6pSum0c61Nu4sSYgnrw8c9KY', '8180072499:AAF_YXOlI2z6pSum0c61Nu4sSYgnrw8c9KY'),
    'chat_id' => env('8012649924'),
];
