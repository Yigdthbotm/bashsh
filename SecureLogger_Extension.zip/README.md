# Secure Logger Blueprint

Blueprint ini menambahkan:
- Proteksi 2FA untuk admin utama saat akses Extensions
- Log ke bot Telegram
- Folder notifikasi suara (notify.mp3)

Letakkan folder ini di `/resources/blueprints` dalam instalasi Pterodactyl kamu.
